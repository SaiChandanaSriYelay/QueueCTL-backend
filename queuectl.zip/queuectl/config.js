
const db = require("./db");

function setConfig(key, value) {
  const stmt = db.prepare("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)");
  stmt.run(key, value);
  console.log(` Config set: ${key} = ${value}`);
}

function getConfig(key, defaultValue) {
  const stmt = db.prepare("SELECT value FROM config WHERE key = ?");
  const row = stmt.get(key);
  return row ? row.value : defaultValue;
}

module.exports = { setConfig, getConfig };

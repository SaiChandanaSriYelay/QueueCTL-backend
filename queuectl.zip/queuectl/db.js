const path = require("path");
const Database = require("better-sqlite3");

const dbPath = path.join(process.cwd(), "queuectl.db");
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  command TEXT,
  state TEXT,
  attempts INTEGER,
  max_retries INTEGER,
  created_at TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS config (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS dlq (
  id TEXT PRIMARY KEY,
  command TEXT,
  reason TEXT,
  failed_at TEXT
);
`);

module.exports = db;

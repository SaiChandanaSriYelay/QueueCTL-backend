const db = require("./db");
const { exec } = require("child_process");
const { moveToDLQ } = require("./jobManager");

function startWorker(id) {
  console.log(`Worker ${id} started`);

  async function processJobs() {
    const job = db
      .prepare("SELECT * FROM jobs WHERE state = 'pending' ORDER BY created_at LIMIT 1")
      .get();

    if (job) {
      console.log(`Worker ${id} processing job: ${job.command}`);
      db.prepare("UPDATE jobs SET state = 'running', updated_at = datetime('now') WHERE id = ?").run(job.id);

      exec(job.command, (error, stdout, stderr) => {
        if (error) {
          console.error(`Job ${job.id} failed: ${error.message}`);
          const attempts = job.attempts + 1;

          if (attempts >= job.max_retries) {
            moveToDLQ(job.id, error.message);
          } else {
            db.prepare(`
              UPDATE jobs
              SET state = 'pending', attempts = ?, updated_at = datetime('now')
              WHERE id = ?
            `).run(attempts, job.id);
            console.log(`Retrying job ${job.id} (attempt ${attempts})`);
          }
        } else {
          db.prepare("UPDATE jobs SET state = 'completed', updated_at = datetime('now') WHERE id = ?").run(job.id);
          console.log(`Job ${job.id} completed successfully`);
          if (stdout.trim()) console.log(`Output: ${stdout.trim()}`);
        }
      });
    }

    setTimeout(processJobs, 3000);
  }

  processJobs();
}

module.exports = { startWorker };

const { execSync } = require("child_process");

console.log("Starting Full QueueCTL System Test (Windows Compatible)...\n");

function run(command, description) {
  console.log(`=== ${description} ===`);
  console.log(`> ${command}`);
  try {
    const output = execSync(command, { stdio: "pipe", maxBuffer: 1024 * 500 }).toString(); 
    console.log(output);
  } catch (err) {
    console.error("Command failed:", err.message);
    if (err.stdout && err.stdout.length > 0) console.error("STDOUT:", err.stdout.toString());
    if (err.stderr && err.stderr.length > 0) console.error("STDERR:", err.stderr.toString());
  }
  console.log("--------------------------------------------------\n");
}

run(
  `node queuectl.js enqueue \"{\\"id\\":\\"jobk\\",\\"command\\":\\"echo Hello from Job A\\"}\"`,
  "Enqueue Job k (Valid)"
);

run(`node queuectl.js list --state pending`, "List Pending Jobs");

console.log(`=== Run Worker to Process Jobs ===`);
const workerCommand = `node queuectl.js worker`;
console.log(`> ${workerCommand}`);
try {
  execSync(workerCommand, { stdio: "inherit", maxBuffer: 1024 * 500 }); 
} catch (err) {
  console.error("Worker process exited with an error. This is expected if an enqueued job failed.");
  console.error(`Error details: ${err.message}`);
}
console.log("--------------------------------------------------\n");

run(`node queuectl.js list --state completed`, "List Completed Jobs");
run(`node queuectl.js list --state failed`, "List Failed Jobs");

run(`node queuectl.js dlq:purge`, "Purge Dead Letter Queue");

console.log("\nTest Completed.\n");

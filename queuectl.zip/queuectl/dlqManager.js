const db = require("./db");
const { enqueue } = require("./jobManager");

function listDLQ() {
  const jobs = db.prepare("SELECT * FROM dlq").all();
  if (!jobs.length) {
    console.log("✅ DLQ is empty");
    return;
  }
  console.table(jobs);
}

function retryDLQ(jobId) {
  const job = db.prepare("SELECT * FROM dlq WHERE id = ?").get(jobId);
  if (!job) {
    console.log("❌ Job not found in DLQ");
    return;
  }

  enqueue({
    id: job.id,
    command: job.command,
    state: "pending",
    attempts: 0,
    max_retries: 3,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  });

  db.prepare("DELETE FROM dlq WHERE id = ?").run(jobId);
  console.log(`🔁 Retried job ${jobId} from DLQ`);
}

module.exports = { listDLQ, retryDLQ };

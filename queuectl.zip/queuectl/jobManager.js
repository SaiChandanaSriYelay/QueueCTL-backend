const db = require("./db");
const { v4: uuidv4 } = require("uuid");


function enqueue(job) {
  const id = job.id || uuidv4(); 
  const maxRetries = job.max_retries || 3;

  try {
    const stmt = db.prepare(`
      INSERT INTO jobs (id, command, state, attempts, max_retries, created_at, updated_at)
      VALUES (?, ?, 'pending', 0, ?, datetime('now'), datetime('now'))
    `);

    stmt.run(id, job.command, maxRetries);
    console.log(`Job enqueued successfully: ${id}`);
  } catch (err) {
    if (err.message.includes("UNIQUE constraint failed")) {
      console.error(`  Job ID "${id}" already exists. Use a different ID.`);
    } else {
      console.error(" Failed to enqueue job:", err.message);
    }
  }
}


function listJobs(state) {
  const rows = db
    .prepare(`SELECT id, command, state, attempts, max_retries FROM jobs WHERE state = ?`)
    .all(state);
  console.table(rows);
}


function moveToDLQ(jobId, reason) {
  const job = db.prepare(`SELECT * FROM jobs WHERE id = ?`).get(jobId);
  if (!job) return console.log(`⚠️  Job ${jobId} not found.`);

  db.prepare(`
    INSERT INTO dlq (id, command, reason, failed_at)
    VALUES (?, ?, ?, datetime('now'))
  `).run(jobId, job.command, reason);

  db.prepare(`DELETE FROM jobs WHERE id = ?`).run(jobId);
  console.log(`☠️  Job ${jobId} moved to DLQ: ${reason}`);
}

function showDLQ() {
  const rows = db.prepare(`SELECT * FROM dlq`).all();
  console.table(rows);
}

function retryDLQ(id) {
  const row = db.prepare(`SELECT * FROM dlq WHERE id = ?`).get(id);
  if (!row) return console.log(" Job not found in DLQ");

  enqueue({ id, command: row.command }); 
  db.prepare(`DELETE FROM dlq WHERE id = ?`).run(id);
  console.log(` Retried DLQ job: ${id}`);
}

function purgeDLQ() {
  db.prepare(`DELETE FROM dlq`).run();
  console.log("🧹 DLQ cleared.");
}

function showSummary() {
  const stats = db
    .prepare(`SELECT state, COUNT(*) AS count FROM jobs GROUP BY state`)
    .all();
  const dlqCount = db.prepare(`SELECT COUNT(*) AS count FROM dlq`).get().count;

  console.log("\n Queue Status Summary:");
  console.log("-------------------------");

  const stateMap = { pending: 0, running: 0, completed: 0, failed: 0 };
  for (const s of stats) stateMap[s.state] = s.count;

  console.table([
    { State: "Pending", Count: stateMap.pending },
    { State: "Running", Count: stateMap.running },
    { State: "Completed", Count: stateMap.completed },
    { State: "Failed", Count: stateMap.failed },
    { State: "DLQ", Count: dlqCount },
  ]);

  console.log("-------------------------\n");
}

module.exports = {
  enqueue,
  listJobs,
  moveToDLQ,
  showDLQ,
  retryDLQ,
  purgeDLQ,
  showSummary,
};

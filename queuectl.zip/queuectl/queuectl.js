
const { Command } = require("commander");
const {
  enqueue,
  listJobs,
  showDLQ,
  retryDLQ,
  purgeDLQ,
  showSummary,
} = require("./jobManager");
const { startWorker } = require("./worker");
const { setConfig } = require("./config");

const program = new Command();
program
  .name("queuectl")
  .description("Background job queue CLI")
  .version("1.0.0");

// enqueue
program
  .command("enqueue")
  .argument("<json>", "Job JSON")
  .description("Add a new job to the queue")
  .action((json) => {
    const job = JSON.parse(json);
    enqueue(job);
  });

// worker
program
  .command("worker")
  .option("--count <num>", "number of workers", "1")
  .description("Start one or more workers to process jobs")
  .action((opts) => {
    const count = parseInt(opts.count);
    for (let i = 0; i < count; i++) startWorker(i + 1);
  });

// list jobs
program
  .command("list")
  .option("--state <state>", "Job state to list", "pending")
  .description("List jobs filtered by state")
  .action((opts) => listJobs(opts.state));


program
  .command("config")
  .command("set")
  .argument("<key>")
  .argument("<value>")
  .description("Set configuration values (e.g. retry delay)")
  .action((key, value) => setConfig(key, value));


program
  .command("dlq:list")
  .description("Show all jobs in Dead Letter Queue")
  .action(showDLQ);

program
  .command("dlq:retry")
  .argument("<id>", "Job ID to retry from DLQ")
  .description("Retry a job that failed and went to DLQ")
  .action(retryDLQ);

program
  .command("dlq:purge")
  .description("Delete all jobs from Dead Letter Queue")
  .action(purgeDLQ);


program
  .command("summary")
  .description("Show queue summary by job state")
  .action(showSummary);

program.parse();
